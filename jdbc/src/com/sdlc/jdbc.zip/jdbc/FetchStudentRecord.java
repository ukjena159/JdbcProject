package com.sdlc.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class FetchStudentRecord 
{

	public static void main(String[] args) 
	{
		 Connection connection=null;
		 Statement st=null;
		 ResultSet rs=null;
		try
          {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			connection = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:xe", "system", "pradip1");

			st = connection.createStatement();

			String fetchData = "select * from student)";
			rs = st.executeQuery(fetchData);
  

			while(rs.next())
			{
				//System.out.println(rs.getInt(1) + " " + rs.getString(2));
				System.out.println(rs.getInt("sid") + " " + rs.getString("name"));
				
			}
		}
		   catch(Exception ex)
		   {
			 ex.printStackTrace();  
		   }
           finally
           {
        	  try {
				rs.close();
				st.close();
	        	connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	  
           }
		
	}

}
